//
//  AppDelegate.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/7/16.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "AppDelegate.h"
#import "PrinterListViewController.h"
#import "LMAPI.h"
#import "Constant.h"
#import "XHudManager.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    self.coverIsOpen = YES;
    self.outofPaper = YES;
    self.cancelPrint = NO;

    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    [self.window makeKeyAndVisible];
    self.window.backgroundColor = UIColor.whiteColor;
    PrinterListViewController *rootVC = [[PrinterListViewController alloc] init];
    self.window.rootViewController = [[UINavigationController alloc] initWithRootViewController:rootVC];

    // 打印机主动提醒
    [LMAPI printerResponse:^(PrinterResponse exception) {
        
        if (exception == PrinterResponseOutofPaper) {
            self.outofPaper = YES;
            [self alter:@"打印机缺纸" type:exception];
            
            return;
        }
        if (exception == PrinterResponseIntoPaper) {
            self.outofPaper = NO;
            //[self alter:@"打印机上纸/有纸" type:exception];
            NO;
            return;
        }
        if (exception == PrinterResponseCoverOpen) {
            self.coverIsOpen = YES;
            [self alter:@"打印机开盖" type:exception];
            return;
        }
        if (exception == PrinterResponseCoverClose) {
            self.coverIsOpen = NO;
            [self alter:@"打印机关盖" type:exception];
            return;
        }
        if (exception == PrinterResponseTemWarining) {
            [self alter:@"打印机温度过高" type:exception];
            return;
        }
        if (exception == PrinterResponseRemoveTemWarining) {
            [self alter:@"打印机高温解除" type:exception];
            return;
        }
        if (exception == PrinterResponseLowPower_10) {
            [self alter:@"打印机电量低于10%" type:exception];
            return;
        }
        if (exception == PrinterResponseLowPower_5) {
            [self alter:@"打印机电量低于5%" type:exception];
            return;
        }
        if (exception == PrinterResponseWillShutdown) {
            [self alter:@"打印机即将关机" type:exception];
            return;
        }
        if (exception == PrinterResponseCancelPrint) {
            self.cancelPrint = YES;
            [self alter:@"打印机取消打印" type:exception];
            [XHudManager.sharedInstance hidden];
            return;
        }
        if (exception == PrinterResponseCutterPress) {
            [self alter:@"打印机切刀被触碰" type:exception];
            return;
        }
        if (exception == PrinterResponseCutterLoosen) {
            //[self alter:@"打印机切刀松开" type:exception];
            return;
        }
        
        if (exception == PrinterResponseTTFError) {
            [self alter:@"打印机碳带识别异常" type:exception];
            return;
        }
        if (exception == PrinterResponseOutofTTF) {
            [self alter:@"打印机碳带耗尽" type:exception];
            return;
        }
        
        if (exception == PrinterResponsePaperError) {
            [self alter:@"打印机纸张识别异常" type:exception];
            return;
        }
        if (exception == PrinterResponsePaperInsufficient) {
            [self alter:@"打印机纸张余量不足" type:exception];
            return;
        }
        if (exception == PrinterResponsePaperError) {
            [self alter:@"打印机色带识别异常" type:exception];
            return;
        }
        if (exception == PrinterResponseOutofTape) {
            [self alter:@"打印机色带耗尽" type:exception];
            return;
        }
        if (exception == PrinterResponseDisconnect) {
            [self alter:@"打印机断开连接" type:exception];
            return;
        }
    }];
    
    return YES;
}


- (void)alter:(NSString *)title type:(PrinterResponse)responseType {
    
    UIAlertController *alter = [UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alter dismissViewControllerAnimated:YES completion:nil];
    }];
    [alter addAction:confirm];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (UIApplication.sharedApplication.keyWindow.rootViewController.presentedViewController) {
            
            [UIApplication.sharedApplication.keyWindow.rootViewController dismissViewControllerAnimated:YES completion:^{
                [UIApplication.sharedApplication.keyWindow.rootViewController presentViewController:alter animated:YES completion:nil];
            }];

        }else {
            [UIApplication.sharedApplication.keyWindow.rootViewController presentViewController:alter animated:YES completion:nil];
        }
        
        
    });
    
    
    
}



@end
