//
//  F12ViewController.m
//  LMAPITest
//
//  Created by aimo on 2024/8/21.
//  Copyright © 2024 YFB-CDS. All rights reserved.
//

#import "F12ViewController.h"
#import "LMAPI.h"
#import "PrinterListViewController.h"
#import "XHudManager.h"
#import "XSingleView.h"


@interface F12ViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>

/**按键数输入框*/
@property(nonatomic, strong) UITextField *regionTF;

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *items;
/**内容宽度，dot*/
@property(nonatomic, assign) CGFloat contentW_dot;
/**内容高度，dot*/
@property(nonatomic, assign) CGFloat contentH_dot;
/**内容宽度，mm*/
@property(nonatomic, assign) CGFloat contentW_mm;
/**内容高度，dot*/
@property(nonatomic, assign) CGFloat contentH_mm;
@end

@implementation F12ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
        
    UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTouchAction)];
    [self.view addGestureRecognizer:gesture];
    
    // 创建tableView
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, X_Width, 500) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    [self.view addSubview:self.tableView];
    
    // 创建导航栏按钮
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonTapped:)];
    self.navigationItem.rightBarButtonItem = addButton;
    
    // 初始化items数组
    self.items = [NSMutableArray array];
    [self.items addObject:@"123123"];
    [self.items addObject:@"国家国家"];
    [self.items addObject:@"说三道四的"];
    [self.items addObject:@"哈哈哈哈哈哈哈哈哈"];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, X_Height-270, X_Width-30, 100)];
    label.text = @"此处获取打印完成内容";
    label.numberOfLines = 0;
    label.layer.cornerRadius = 3;
    label.layer.borderWidth = 1;
    label.layer.borderColor = UIColor.grayColor.CGColor;
    [self.view addSubview:label];

    // 添加文本框
    UILabel *countLb = [[UILabel alloc] initWithFrame:CGRectMake(15, X_Height-150, 100, 30)];
    countLb.text = @"按键：";
    countLb.textColor = UIColor.blackColor;
    [self.view addSubview:countLb];
    
    _regionTF = [[UITextField alloc] initWithFrame:CGRectMake(115, X_Height-150, X_Width-130, 30)];
    _regionTF.placeholder = @"请输入按键(0\1\2)";
    _regionTF.text = @"0";
    _regionTF.layer.cornerRadius = 3;
    _regionTF.layer.borderWidth = 1;
    _regionTF.layer.borderColor = UIColor.grayColor.CGColor;
    _regionTF.keyboardType = UIKeyboardTypeNumberPad;
    _regionTF.delegate = self;
    [self.view addSubview:_regionTF];

    // 上传按钮
    UIButton *printBtn = [[UIButton alloc] initWithFrame:CGRectMake(15, X_Height-100, X_Width-30, 50)];
    [printBtn setTitle:@"上传到打印机" forState:UIControlStateNormal];
    printBtn.backgroundColor = UIColor.whiteColor;
    [printBtn addTarget:self action:@selector(footerButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    [printBtn setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    printBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    printBtn.layer.cornerRadius = 5;
    [self.view addSubview:printBtn];
    
    self.contentW_dot = 104;
    self.contentH_dot = 32;
    self.contentW_mm = _contentW_dot / 8;
    self.contentH_mm = _contentH_dot / 8;
    
    [LMAPI getPrintText:^(NSString *text) {
        label.text = text;
    }];
}

- (void)viewTouchAction {
    [_regionTF endEditing:YES];
}

- (void)addButtonTapped:(NSInteger)index {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"添加文本内容" message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"输入文本内容";
    }];
    
    UIAlertAction *addAction = [UIAlertAction actionWithTitle:@"添加" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UITextField *textField = alertController.textFields.firstObject;
        if (textField.text.length > 0) {
            if (index < self.items.count && index >= 0) {
                [self.items replaceObjectAtIndex:index withObject:textField.text];
            } else {
                [self.items addObject:textField.text];
            }
            [self.tableView reloadData];
        }
    }];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alertController addAction:addAction];
    [alertController addAction:cancelAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)footerButtonTapped {
    // 未连接，前往连接
    if (![LMAPI printerIsConnect]) {
        PrinterListViewController *listVC = [[PrinterListViewController alloc] init];
        listVC.view.backgroundColor = [UIColor whiteColor];
        [self.navigationController pushViewController:listVC animated:true];
        return;
    }
    
    [XHudManager.sharedInstance show:@"正在写入..."];
    [LMAPI sendPrintEntries:self.items region:[_regionTF.text integerValue] completion:^(BOOL sendSuccess) {
            if (sendSuccess) {
                [XSingleView.sharedInstance show:@"写入成功"];
            }else {
                [XSingleView.sharedInstance show:@"写入失败"];
            }
            [XHudManager.sharedInstance hidden];
    }];
    
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    _regionTF.text = @"";
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField.text.length <= 0) {
        _regionTF.text = @"0";
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.items.count; // 固定行数为10
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    NSInteger row = indexPath.row;
    
    cell.textLabel.text = self.items[row];
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self addButtonTapped: indexPath.row];
}

@end
