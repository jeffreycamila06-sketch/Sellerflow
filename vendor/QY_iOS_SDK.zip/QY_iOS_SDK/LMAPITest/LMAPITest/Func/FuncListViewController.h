//
//  RootViewController.h
//  LMAPITest
//
//  Created by YFB-CDS on 2020/7/24.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "BaseViewController.h"
#import "LMAPI.h"
NS_ASSUME_NONNULL_BEGIN

@interface FuncListViewController : BaseViewController

@property(nonatomic, strong) QYPrinterInfo *printerInfo;
@property(nonatomic, strong) BLEPeripheral * peripheral;
@end

NS_ASSUME_NONNULL_END
