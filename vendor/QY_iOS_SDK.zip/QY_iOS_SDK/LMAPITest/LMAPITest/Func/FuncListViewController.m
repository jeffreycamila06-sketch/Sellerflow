//
//  RootViewController.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/7/24.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "FuncListViewController.h"
#import "PrinterListViewController.h"
#import "Constant.h"
#import "FuncViewController.h"
#import "F12ViewController.h"

@interface FuncListViewController () <UITableViewDelegate, UITableViewDataSource>

/**功能列表*/
@property(nonatomic, strong) UITableView *funcTab;
/**功能标题*/
@property(nonatomic, strong) NSArray *funcTitles;

@end

@implementation FuncListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"功能列表";
    
    _funcTitles = @[@"打印文本", @"打印条码", @"打印二维码", @"打印线条", @"打印线框", @"打印图片", @"PDF", @"生成打印词条", @"重置词条", @"同步日期"];
   
    _funcTab = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, X_Width, X_Height-50)];
    [_funcTab registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    _funcTab.delegate = self;
    _funcTab.dataSource = self;
    _funcTab.tableFooterView = [UIView new];
    [self.view addSubview:_funcTab];
    
    if ([_peripheral.peripheral.name isEqualToString:@"F12"]) {
        NSDate *currentDate = [NSDate date];
        
        // 创建日历对象
        NSCalendar *calendar = [NSCalendar currentCalendar];
        
        // 获取年、月、日的组件
        NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:currentDate];
        NSInteger year = components.year;
        NSInteger month = components.month;
        NSInteger day = components.day;
        [LMAPI setPrinterDate:year month:month day:day];
    }
}

#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _funcTitles.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.textLabel.text = self.funcTitles[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == 7) {
        F12ViewController *f12VC = [[F12ViewController alloc] init];
        [self.navigationController pushViewController:f12VC animated:YES];
    } else if (indexPath.row == 8) {
        // 重置词条
        [LMAPI resetPrintEntries];
    } else if (indexPath.row == 9) {
        [self showDatePicker];
    } else {
        FuncViewController *funcVC = [[FuncViewController alloc] init];
        funcVC.title = self.funcTitles[indexPath.row];
        funcVC.printerInfo = self.printerInfo;
        funcVC.peripheral = self.peripheral;
        funcVC.view.backgroundColor = [UIColor colorWithRed:243/255.0 green:243/255.0 blue:248/255.0 alpha:1.0];
        [funcVC setFuncType:indexPath.row];
        [self.navigationController pushViewController:funcVC animated:YES];
    }
    [tableView reloadData];
}

- (void)showDatePicker {
    // 创建日期选择器
    UIDatePicker *datePicker = [[UIDatePicker alloc] init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    
    // 创建弹窗控制器
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"选择日期" preferredStyle:UIAlertControllerStyleActionSheet];
    
    // 添加日期选择器到弹窗控制器
    [alertController.view addSubview:datePicker];
    
    // 创建确定按钮并添加到弹窗控制器
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        // 获取选择的日期
        NSDate *selectedDate = datePicker.date;
        
        // 在这里可以获取选择的年、月、日并进行处理
        NSCalendar *calendar = [NSCalendar currentCalendar];
        NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:selectedDate];
        NSInteger year = components.year;
        NSInteger month = components.month;
        NSInteger day = components.day;
        
        [LMAPI setPrinterDate:year month:month day:day];
    }];
    [alertController addAction:confirmAction];
    
    // 创建取消按钮并添加到弹窗控制器
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertController addAction:cancelAction];
    
    // 在视图控制器中呈现弹窗控制器
    [self presentViewController:alertController animated:YES completion:nil];
}
@end
