//
//  FuncViewController.h
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/17.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "BaseViewController.h"
#import "LMAPI.h"
typedef enum : NSUInteger {
    Text,
    Barcode,
    QRCode,
    Line,
    Form,
    Image,
    PDF,
    F12PrintData,
} FunctionType;


@interface FuncViewController : BaseViewController

@property(nonatomic, strong) QYPrinterInfo *printerInfo;
@property(nonatomic, strong) BLEPeripheral * peripheral;

/**功能类型*/
- (void)setFuncType:(FunctionType)funcType;

@end

