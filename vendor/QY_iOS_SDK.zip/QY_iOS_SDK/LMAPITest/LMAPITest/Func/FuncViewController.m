//
//  FuncViewController.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/17.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "FuncViewController.h"
#import "Constant.h"
#import "LMAPI.h"
#import "PrinterListViewController.h"
#import "XHudManager.h"
#import "XSingleView.h"
#import "AppDelegate.h"
#import "PDFUtil.h"
 
@interface FuncViewController () <UIScrollViewDelegate, UITextFieldDelegate>

/**内容滚动视图*/
@property(nonatomic, strong) UIScrollView *contenScr;
/**内容视图*/
@property(nonatomic, strong) UIImageView *contentView;
/**打印份数输入框*/
@property(nonatomic, strong) UITextField *printCountTF;
/**打印按钮*/
@property(nonatomic, strong) UIButton *printBtn;
/**功能类型*/
@property(nonatomic, assign) FunctionType type;
/**内容宽度，dot*/
@property(nonatomic, assign) CGFloat contentW_dot;
/**内容高度，dot*/
@property(nonatomic, assign) CGFloat contentH_dot;
/**内容宽度，mm*/
@property(nonatomic, assign) CGFloat contentW_mm;
/**内容高度，dot*/
@property(nonatomic, assign) CGFloat contentH_mm;

@end

@implementation FuncViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
 
    //self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"打印" style:UIBarButtonItemStyleDone target:self action:@selector(print)];
    UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTouchAction)];
    [self.view addGestureRecognizer:gesture];
    
    if ([[[self.peripheral peripheral] name] hasPrefix:@"D"] ||
        [[[self.peripheral peripheral] name] hasPrefix:@"P"] ||
        [[[self.peripheral peripheral] name] hasPrefix:@"Q30"] ||
        [[[self.peripheral peripheral] name] hasPrefix:@"Q31"] ||
        [[[self.peripheral peripheral] name] hasPrefix:@"Q32"]
        )
    {
        self.contentW_mm = 40;
        self.contentH_mm = 12;
    }
    else if ([[[self.peripheral peripheral] name] hasPrefix:@"Q218"]) {
        self.contentW_mm = 72;
        self.contentH_mm = 30;
    }
    else if ([[[self.peripheral peripheral] name] hasPrefix:@"6XL"]) {
        self.contentW_mm = 102;
        self.contentH_mm = 50;
    }
    else if ([[[self.peripheral peripheral] name] hasPrefix:@"QR380A"]||[[[self.peripheral peripheral] name] hasPrefix:@"AM-243Z"]) {
        self.contentW_mm = 100;
        self.contentH_mm = 150;
    } else if ([[[self.peripheral peripheral] name] hasPrefix:@"KT-320"]||[[[self.peripheral peripheral] name] hasPrefix:@"KT320"] || [[[self.peripheral peripheral] name] hasPrefix:@"JP02"]) {
        self.contentW_mm = 252;
        self.contentH_mm = 60;
    }
    else{
        self.contentW_mm = 40;
        self.contentH_mm = 30;
    }
    
    self.contentW_dot = _contentW_mm*8;
    self.contentH_dot = _contentH_mm*8;
    
    CGFloat scrWidth = X_Width-30;
    CGFloat scrHeight = scrWidth*(_contentH_dot/_contentW_dot);
    self.contenScr = [[UIScrollView alloc] initWithFrame:CGRectMake(15, 130, scrWidth, scrHeight)];
    self.contenScr.layer.cornerRadius = 10;
    self.contenScr.layer.masksToBounds = YES;
    self.contenScr.backgroundColor = UIColor.whiteColor;
    self.contenScr.delegate = self;
    
    [self.view addSubview:self.contenScr];
    
    // 内容视图
    self.contentView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, _contentW_dot, _contentH_dot)];
    [self.contenScr addSubview:self.contentView];
    
    // 设置放大系数
    CGFloat scale = self.contenScr.frame.size.width/_contentW_dot;
    
    self.contenScr.maximumZoomScale = scale;
    self.contenScr.minimumZoomScale = scale;
    [self.contenScr setZoomScale:scale];
    self.contenScr.contentSize = CGSizeMake(_contentW_dot, _contentH_dot);
    // 添加文本框
    UILabel *countLb = [[UILabel alloc] initWithFrame:CGRectMake(15, X_Height-150, 100, 30)];
    countLb.text = @"打印份数：";
    countLb.textColor = UIColor.blackColor;
    [self.view addSubview:countLb];
    
    _printCountTF = [[UITextField alloc] initWithFrame:CGRectMake(115, X_Height-150, X_Width-130, 30)];
    _printCountTF.placeholder = @"请输入打印份数";
    _printCountTF.text = @"1";
    _printCountTF.layer.cornerRadius = 3;
    _printCountTF.layer.borderWidth = 1;
    _printCountTF.layer.borderColor = UIColor.grayColor.CGColor;
    _printCountTF.keyboardType = UIKeyboardTypeNumberPad;
    _printCountTF.delegate = self;
    [self.view addSubview:_printCountTF];

    // 打印按钮
    UIButton *printBtn = [[UIButton alloc] initWithFrame:CGRectMake(15, X_Height-100, X_Width-30, 50)];
    [printBtn setTitle:@"打印" forState:UIControlStateNormal];
    printBtn.backgroundColor = UIColor.whiteColor;
    [printBtn addTarget:self action:@selector(print) forControlEvents:UIControlEventTouchUpInside];
    [printBtn setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
    printBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    printBtn.layer.cornerRadius = 5;
    [self.view addSubview:printBtn];
}



- (void)setFuncType:(FunctionType)funcType {
    self.type = funcType;
    [LMAPI startDrawWithWidth:_contentW_mm height:_contentH_mm orientation:0];
    switch (self.type) {
        case Text:
            [self drawText];
            break;
        case Barcode:
            [self drawBarcode];
            break;
        case QRCode:
            [self drawQRCode];
            break;
        case Line:
            [self drawLine];
            break;
        case Form:
            [self drawForm];
            break;
        case Image:
            [self drawImage];
            break;
        default:
            break;
    }
    [LMAPI preView:^(UIImage *previewImage) {
        self.contentView.image = previewImage;
    }];
}
- (void)viewTouchAction {
    [_printCountTF endEditing:YES];
}

#pragma mark UIScrollViewDelegate
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    return self.contentView;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    _printCountTF.text = @"";
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField.text.length <= 0) {
        _printCountTF.text = @"1";
    }
}

#pragma mark 打印
- (void)print {
    
    NSInteger printCount = [_printCountTF.text integerValue];
    // 未连接，前往连接
    if (![LMAPI printerIsConnect]) {
        PrinterListViewController *listVC = [[PrinterListViewController alloc] init];
        listVC.view.backgroundColor = [UIColor whiteColor];
        [self.navigationController pushViewController:listVC animated:true];
        return;
    }
    AppDelegate *delegate = (AppDelegate *)UIApplication.sharedApplication.delegate;
//    if (delegate.coverIsOpen) {
//        [XSingleView.sharedInstance show:@"纸仓盖打开"];
//        return;
//    }
//    if (delegate.outofPaper) {
//        [XSingleView.sharedInstance show:@"打印机缺纸"];
//        return;
//    }
    [XHudManager.sharedInstance show:@"正在打印..."];
    if (self.type != PDF) {
        // 非PDF打印
        // 打印
        // 开始绘制
        [LMAPI startDrawWithWidth:_contentW_mm height:_contentH_mm orientation:0];

        switch (self.type) {
            case Text:
                [self drawText];
                break;
            case Barcode:
                [self drawBarcode];
                break;
            case QRCode:
                [self drawQRCode];
                break;
            case Line:
                [self drawLine];
                break;
            case Form:
                [self drawForm];
                break;
            case Image:
                [self drawImage];
                break;
            default:
                break;
        }
        delegate.cancelPrint = NO;
        [LMAPI print:printCount completion:^(BOOL isSuccess) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (isSuccess) {
                    [XSingleView.sharedInstance show:@"打印成功"];
                }else {
                    [XSingleView.sharedInstance show:@"打印失败"];
                }
                [XHudManager.sharedInstance hidden];
            });
        }];
    }else {
        // PDF打印
        NSString *path = [[NSBundle mainBundle] pathForResource:@"test4" ofType:@"pdf"];

        UIImage *image = [PDFUtil toImage:path width:792 pageNumber:1];

        [LMAPI printPDFImage:image count:printCount dithering:NO completion:^(BOOL isSuccess) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (isSuccess) {
                    [XSingleView.sharedInstance show:@"打印成功"];
                }else {
                    [XSingleView.sharedInstance show:@"打印失败"];
                }
                [XHudManager.sharedInstance hidden];
            });
        }];
        
//        [LMAPI B246DPrintPDFImage:image count:printCount dithering:NO offsetX:3 offsetY:-3 completion:^(BOOL isSuccess) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//                if (isSuccess) {
//                    [XSingleView.sharedInstance show:@"打印成功"];
//                }else {
//                    [XSingleView.sharedInstance show:@"打印失败"];
//                }
//                [XHudManager.sharedInstance hidden];
//            });
//        }];
    }
    
        

}


#pragma mark 绘制视图

/**
 * @brief 打印文本
 */
- (void)drawText {
    
    
    ElementLocation *textLocation = [[ElementLocation alloc] init];
    textLocation.x = 0;
    textLocation.y = (_contentH_dot-35)/2;
    textLocation.width = _contentW_dot;
    textLocation.height = 35;
    TextInfo *textInfo = [[TextInfo alloc] init];
    textInfo.location = textLocation;
    textInfo.fontSize = 30;
    textInfo.text = @"珠海趣印科技有限公司";
    textInfo.aligment = TextAligmentCenter;
    [LMAPI drawText:textInfo];
}

- (void)drawBarcode {
    
    CGFloat width = 113*2;
    TextInfo *textInfo = [[TextInfo alloc] init];
    textInfo.fontSize = 18;
    textInfo.fontName = @"PingFang SC";
    textInfo.text = @"620123456789";
    textInfo.aligment = TextAligmentJustified;
    
    
    ElementLocation *barcodeLocation = [[ElementLocation alloc] init];
    barcodeLocation.x = (_contentW_dot-width)/2;
    barcodeLocation.y = (_contentH_dot-60)/2;
    barcodeLocation.width = width;
    barcodeLocation.height = 60;
    BarcodeInfo *barcodeInfo = [[BarcodeInfo alloc] init];
    barcodeInfo.location = barcodeLocation;
    barcodeInfo.scale = 2;
    barcodeInfo.textInfo = textInfo;
    barcodeInfo.showText = true;
    barcodeInfo.showLongline = true;
    barcodeInfo.showAsterisk = true;
    barcodeInfo.showArrow = true;
    barcodeInfo.barcodeType = BarcodeTypeEAN_13;
    [LMAPI drawBarcode:barcodeInfo];
    
}

- (void)drawQRCode {
    CGFloat width = _contentH_dot-20;
    ElementLocation *qrcodeLocation = [[ElementLocation alloc] init];
    qrcodeLocation.x = (_contentW_dot-width)/2;
    qrcodeLocation.y = (_contentH_dot-width)/2;
    qrcodeLocation.width = width;
    qrcodeLocation.height = width;
    QRCodeInfo *qrcodeInfo = [[QRCodeInfo alloc] init];
    qrcodeInfo.level = ErrorCorrectionLevelLow;
    qrcodeInfo.content = @"珠海趣印科技有限公司";
    qrcodeInfo.location = qrcodeLocation;
    [LMAPI drawQRCode:qrcodeInfo];
}

- (void)drawLine {
    
    ElementLocation *lineLocation = [[ElementLocation alloc] init];
    
    lineLocation.x = 40;
    lineLocation.y = (_contentH_dot-2)/2;
    lineLocation.width = _contentW_dot-80;
    lineLocation.height = 5;
    LineInfo *lineInfo = [[LineInfo alloc] init];
    lineInfo.lineType = LineTypeDottedLine;
    lineInfo.interval = 4;
    lineInfo.location = lineLocation;
    [LMAPI drawLine:lineInfo];
}

- (void)drawForm {
    
    ElementLocation *shapeLocation = [[ElementLocation alloc] init];
    shapeLocation.x = 40;
    shapeLocation.y = 10;
    shapeLocation.width = _contentW_dot-80;
    shapeLocation.height = _contentH_dot-20;
    
    ShapeInfo *shapeInfo = [[ShapeInfo alloc] init];
    shapeInfo.location = shapeLocation;
    shapeInfo.shapeType = ShapeTypeCircularBead;
    shapeInfo.lineWidth = 3;
    shapeInfo.fill = NO;
    [LMAPI drawShape:shapeInfo];
  

}

- (void)drawImage {
    
    ElementLocation *imgLocation = [[ElementLocation alloc] init];
    imgLocation.x = 40;
    imgLocation.y = 10;
    imgLocation.width = _contentW_dot-80;
    imgLocation.height = _contentH_dot-20;
    
    ImageInfo *imgInfo = [[ImageInfo alloc] init];
    imgInfo.colorModel = ImageColorModelDither;
    imgInfo.image = [UIImage imageNamed:@"quin"];
    imgInfo.location = imgLocation;
    imgInfo.tile = NO;
    [LMAPI drawImage:imgInfo];
}

@end
