//
//  LMAPI.h
//  LMAPI
//
//  Created by YFB-CDS on 2020/7/15.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <UIKit/UIKit.h>


#pragma mark 外设信息
@interface BLEPeripheral : NSObject
/**外设*/
@property(nonatomic, strong) CBPeripheral *peripheral;
/**外设mac地址*/
@property(nonatomic, copy) NSString *mac;
/**外设是否已连接*/
@property(nonatomic, assign) BOOL isConnected;
/**是否WIFI设备**/
@property(nonatomic, assign) BOOL isWiFiPeripheral;
@end

#pragma mark 打印机Wifi模块扫描的Wifi信息
@interface WifiInfo : NSObject
/**Wifi信号量**/
@property(nonatomic, assign) int rssi;
/**Wifi名称**/
@property(nonatomic, copy) NSString *name;
@end

#pragma mark 标签信息

@interface LabelInfo : NSObject
/**
 * 纸张类型
 */
typedef NS_OPTIONS(int, PaperType) {
    /**连续纸*/
    PaperTypeContinuous     = 1,
    /**定位孔*/
    PaperTypeLocationHole   = 2,
    /**间隙纸*/
    PaperTypeInterval       = 3,
    /**黑标纸*/
    PaperTypeBlackLabel     = 4,
    
};


/**是否缺纸，YES为缺纸*/
@property(nonatomic, assign) BOOL outofPaper;

/**纸张类型*/
@property(nonatomic, assign) PaperType paperType;


/*******以下信息只适用于加密打印机**************/

/**RFID标签纸张序列号*/
@property(nonatomic, copy) NSString *paperNumber;
/**RFID标签纸张剩余长度，mm*/
@property(nonatomic, assign) int overlength;
/**RFID标签纸张剩余张数*/
@property(nonatomic, assign) int remainingCount;
@end


#pragma mark 打印机信息

@interface QYPrinterInfo : NSObject

/**打印机系列*/
@property(nonatomic, copy) NSString *serie;

/**打印机类型*/
@property(nonatomic, copy) NSString *type;

/**打印机精度，DPI
 180DPI、203DPI、300DPI
 */
@property(nonatomic, assign) int deviceDPI;

/**打印机最大的打印宽度，mm*/
@property(nonatomic, assign) int maxPrintWidth;

/**打印机最大的打印宽度，dot*/
@property(nonatomic, assign) int maxPrintWidthDot;

/**设备名称*/
@property(nonatomic, copy) NSString *deviceName;

/**设备固件版本号*/
@property(nonatomic, copy) NSString *firmwareVersion;

/**设备MAC地址*/
@property(nonatomic, copy) NSString *mac;

/**设备ID*/
@property(nonatomic, copy) NSString *deviceID;

/**设备剩余电量，百分比
 如返回50，则剩余电量为50%
 */
@property(nonatomic, assign) int remainingBattery;

/**设备自动关机时间，单位分钟
 如返回5，则自动关机时间为5分钟
 如果返回值为10000，则不自动关机
 */
@property(nonatomic, assign) int shutdownTime;

/**打印头温度
 常温时返回0
 高温时返回具体的温度
 */
@property(nonatomic, assign) int temperature;
/** 打印机当前打印浓度
 注意：仅B246D有浓度
 返回值：1-15
 其他打印机无打印浓度，返回0
 */
@property(nonatomic, assign) int concentration;
/** 打印机当前打印速度
 注意：仅B246D有速度
 返回值：1-5
 其他打印机无打印速度，返回0
 */
@property(nonatomic, assign) int speed;

/*******以下信息只适用于加密打印机**************/
/**RFID色带序列号*/
@property(nonatomic, copy) NSString *ribbonNumber;

/**RFID标签碳带序列号*/
@property(nonatomic, copy) NSString *ttfNumber;
/**RFID碳带剩余长度，mm*/
@property(nonatomic, assign) int ttfOverlength;
/**RFID色带剩余长度，mm*/
@property(nonatomic, assign) int ribbonOverlength;

/**余量，单位米
 B246D设备才有
 **/
@property(nonatomic, assign) int B246DOverlength;


@end




#pragma mark 元素位置信息
/**
 * 绘制元素的旋转角度
 */
typedef NS_OPTIONS(NSUInteger, ElementAngle) {
    /**0度*/
    ElementAngleNormalAngle  = 0,
    /**顺时针旋转90度*/
    ElementAngleRightAngle   = 90,
    /**旋转180度*/
    ElementAngleBottomAngle  = 180,
    /**顺时针旋转270度*/
    ElementAngleLeftAngle    = 270,
};
/**
 *元素的位置
 *如果是经过旋转，需要传旋转后的坐标
 */
@interface ElementLocation : NSObject
/**origin x*/
@property(nonatomic, assign) CGFloat x;
/**origin y*/
@property(nonatomic, assign) CGFloat y;
/**宽度*/
@property(nonatomic, assign) CGFloat width;
/**高度*/
@property(nonatomic, assign) CGFloat height;
/**旋转角度*/
@property(nonatomic, assign) ElementAngle angle;

@end

#pragma mark 文本元素信息
/**
 * 文本对齐，默认居左
 */
typedef NS_OPTIONS(NSUInteger, TextAligment) {
    /**居左*/
    TextAligmentLeft        = 1,
    /**居中*/
    TextAligmentCenter      = 2,
    /**居右*/
    TextAligmentRight       = 3,
    /**两端对齐*/
    TextAligmentJustified   = 4,
};

@interface TextInfo : NSObject
/**位置信息*/
@property(nonatomic, strong) ElementLocation *location;
/**文本内容*/
@property(nonatomic, copy) NSString *text;
/**字体名称，默认PingFang SC，该值为字体包解压后实际的名称*/
@property(nonatomic, copy) NSString *fontName;
/**字体大小*/
@property(nonatomic, assign) CGFloat fontSize;
/**文本对齐方式*/
@property(nonatomic, assign) TextAligment aligment;
/**是否加粗*/
@property(nonatomic, assign) BOOL bold;
/**是否斜体*/
@property(nonatomic, assign) BOOL italic;
/**是否需要下划线*/
@property(nonatomic, assign) BOOL underline;
/**是否需要删除线*/
@property(nonatomic, assign) BOOL strikethrough;
/**行间距*/
@property(nonatomic, assign) CGFloat leading;
/**多少倍行间距*/
@property(nonatomic, assign) CGFloat lineSpace;
/**字符间距*/
@property(nonatomic, assign) CGFloat kerning;
/**扇形文本（1:上拱形，2:下拱形）*/
@property(nonatomic, assign) NSInteger arcDirection;
@end


#pragma mark 条码元素信息
/**
 * 条码类型
 */
typedef NS_OPTIONS(NSUInteger, BarcodeType) {
    /**Code128*/
    BarcodeTypeCode128  = 1,
    /**Code39*/
    BarcodeTypeCode39   = 2,
    /**Codabar*/
    BarcodeTypeCodabar  = 3,
    /**EAN_8*/
    BarcodeTypeEAN_8    = 4,
    /**EAN_13*/
    BarcodeTypeEAN_13   = 5,
    /**UPC_A*/
    BarcodeTypeUPC_A    = 6,
};

@interface BarcodeInfo : NSObject

/**位置信息*/
@property(nonatomic, strong) ElementLocation *location;
/**条码类型*/
@property(nonatomic, assign) BarcodeType barcodeType;
/**绘制的条码基于最小绘制宽度的倍数*/
@property(nonatomic, assign) NSInteger scale;
/**条码的文本信息*/
@property(nonatomic, assign) TextInfo *textInfo;
/**是否显示条码文本*/
@property(nonatomic, assign) BOOL showText;
/**是否显示条码"*"号,code39专用*/
@property(nonatomic, assign) BOOL showAsterisk;
/**是否显示条码">"号,EAN-8、EAN-13、UPCA专用*/
@property(nonatomic, assign) BOOL showArrow;
/**是否显示长线条,EAN-8、EAN-13、UPCA专用*/
@property(nonatomic, assign) BOOL showLongline;

@end


#pragma mark 二维码元素信息

/**
 *二维码纠错级别
 */
typedef NS_OPTIONS(NSUInteger, ErrorCorrectionLevel) {
    /**低*/
    ErrorCorrectionLevelLow     = 1,
    /**中*/
    ErrorCorrectionLevelMiddle  = 2,
    /**高*/
    ErrorCorrectionLevelHight   = 3,
    /**强*/
    ErrorCorrectionLevelStrong  = 4,
};

@interface QRCodeInfo: NSObject
/**位置信息*/
@property(nonatomic, strong) ElementLocation *location;
/**纠错级别*/
@property(nonatomic, assign) ErrorCorrectionLevel level;
/**内容*/
@property(nonatomic, copy) NSString *content;

@end


/**
 * 图片颜色模式
 */
typedef NS_OPTIONS(NSUInteger, ImageColorModel) {
    /**原始色调*/
    ImageColorModelOriginal        = 1,
    /**256灰度*/
    ImageColorModelGray256         = 2,
    /**黑白双色*/
    ImageColorModelBackAndWhite    = 3,
    /**半色调*/
    ImageColorModelHalftone        = 4,
    /**抖动*/
    ImageColorModelDither          = 5,
};
@interface ImageInfo: NSObject

/**位置信息*/
@property(nonatomic, strong) ElementLocation *location;
/**图片*/
@property(nonatomic, strong) UIImage *image;
/**颜色模式*/
@property(nonatomic, assign) ImageColorModel colorModel;
/**是否铺满*/
@property(nonatomic, assign) BOOL tile;

@end

#pragma mark 线条信息
/**
 * 线条类型
 */
typedef NS_OPTIONS(NSUInteger, LineType) {
    /**实线*/
    LineTypeFullLine    = 1,
    /**虚线*/
    LineTypeDottedLine  = 2,
};
@interface LineInfo: NSObject

/**位置信息*/
@property(nonatomic, strong) ElementLocation *location;
/**线条类型*/
@property(nonatomic, assign) LineType lineType;
/**虚线间隔*/
@property(nonatomic, assign) NSInteger interval;

@end

#pragma mark 线框信息
/**
 * 线框类型
 */
typedef NS_OPTIONS(NSUInteger, ShapeType) {
    /**直角矩形*/
    ShapeTypeRectAngle       = 1,
    /**圆角矩形*/
    ShapeTypeCircularBead    = 2,
    /**圆*/
    ShapeTypeCircle          = 3,
    /**椭圆*/
    ShapeTypeEllipse         = 4,
};

@interface ShapeInfo: NSObject

/**位置信息*/
@property(nonatomic, strong) ElementLocation *location;
/**线框类型*/
@property(nonatomic, assign) ShapeType shapeType;
/**线条宽度*/
@property(nonatomic, assign) CGFloat lineWidth;
/**是否填满*/
@property(nonatomic, assign) BOOL fill;

@end

#pragma mark 蓝牙状态
/**
 * 蓝牙状态
 */
typedef NS_OPTIONS(NSUInteger, BLEStatus) {
    /**未知*/
    BLEStatusUnknown = 1,
    /**重置中*/
    BLEStatusResetting,
    /**未支持*/
    BLEStatusUnsupported,
    /**未授权*/
    BLEStatusUnauthorized,
    /**已开启*/
    BLEStatusPoweredOff,
    /**已关闭*/
    BLEStatusPoweredOn,
};

#pragma mark 打印机主动回调
/**
 * 打印机主动回调
 */
typedef NS_OPTIONS(NSUInteger, PrinterResponse) {
    /**缺纸*/
    PrinterResponseOutofPaper          = 1,
    /**上纸*/
    PrinterResponseIntoPaper           = 2,
    /**开盖*/
    PrinterResponseCoverOpen           = 3,
    /**关盖*/
    PrinterResponseCoverClose          = 4,
    /**高温报警*/
    PrinterResponseTemWarining         = 5,
    /**解除高温报警*/
    PrinterResponseRemoveTemWarining   = 6,
    /**电量低于10%*/
    PrinterResponseLowPower_10         = 7,
    /**电量低于5%*/
    PrinterResponseLowPower_5          = 8,
    /**即将关机*/
    PrinterResponseWillShutdown        = 9,
    /**干电池电量不足，干电池专有*/
    PrinterResponseLowPower            = 10,
    /**取消打印*/
    PrinterResponseCancelPrint         = 11,
    /**打印机断开连接*/
    PrinterResponseDisconnect          = 12,
    /***以下P1000专属*/
    /**切刀按下*/
    PrinterResponseCutterPress         = 13,
    /**切刀松开*/
    PrinterResponseCutterLoosen        = 14,
    
    /**以下加密机器专属*/
    /**碳带异常*/
    PrinterResponseTTFError            = 15,
    /**碳带耗尽*/
    PrinterResponseOutofTTF            = 16,
    /**纸张异常*/
    PrinterResponsePaperError          = 17,
    /**纸张余量不足*/
    PrinterResponsePaperInsufficient   = 18,
    /**色带异常*/
    PrinterResponseTapeError           = 19,
    /**色带正常*/
    PrinterResponseOutofTape           = 20,
   
};

@interface LMAPI : NSObject


#pragma mark 是否开启调试日志
/**
 * @brief 是否开启调试日志
 * @param open true or false
 */
+ (void)setLogStatus:(BOOL)open;

# pragma mark 打印机搜索，连接

/**
 * @brief 检查蓝牙状态
 * @param completion 蓝牙状态回调闭包，蓝牙状态更新时也会回调
 */
+ (void)BLEStatus:(void(^)(BLEStatus state))completion;
/**
 * @brief 搜索打印机
 * @param completion 打印机设备
 * 返回数组格式[BLEPeripheral]
 */
+ (void)scanPrinter:(void(^)(NSArray *printers))completion;
/**
 @breif 停止扫描
 */
+ (void)stopScan;

/**
 * @brief 指定打印机mac地址连接打印机，推荐使用
 * @param mac 打印机MAC地址
 * @param completion 连接是否成功
 */
+ (void)connectPrinterWithMac:(NSString *)mac
            completion:(void(^)(BOOL isSuccess))completion;

/**
 * @brief 指定打印机名称连接打印机，不推荐，名称可能重复
 * @param printerName 打印机名称
 * @param completion 连接是否成功
 */
+ (void)connectPrinter:(NSString *)printerName
            completion:(void(^)(BOOL isSuccess))completion;


/**
 * @brief 断开当前连接的打印机
 * @return completion断开是否成功
 */
+ (void)disConnectPrinter:(void(^)(BOOL isSuccess))completion;


#pragma mark WIFI连接，仅B246D设备才有

/**通过Mac地址获取打印机WiFi的IP地址
 该方法会调用蓝牙连接，并通过蓝牙通讯，查询IP地址并返回
 * @param mac 打印机蓝牙Mac地址
 * @param completion ip地址回调及错误信息
 如果ip为nil则表示未能识别到Wifi模块
 如果ip为0.0.0.0则表示打印机Wifi模块未连接任何Wifi，需进行配网
 如果ip不为0.0.0.0则表示打印机Wifi模块已配网
 **/
+ (void)getIpWithMac:(NSString *)mac
          completion:(void(^)(NSString *ip, NSError *error))completion;
/**
 * @brief 扫描WiFi
 * @param completion 回调WifiInfo数组
 */
+ (void)scanWifi:(void(^)(NSArray *wifiArray))completion;
/**
* @brief 配置打印机连接的Wifi
 该方法在打印机ip地址为0.0.0.0时使用，需配网再建立长连接
 如果手机连接的Wifi与打印机配置的Wifi是同一个，则可以进行局域网打印
* @param wifiName Wifi名称
* @param password Wifi密码
* @param completion 回调是否成功及错误信息，成功会回调配网后的IP
 建议：配网成功后的IP可以根据Mac地址进行缓存，下次可以直接使用以下方法进行建立wifi连接，则无需通过蓝牙连接
 ‘wifiConnect:(NSString *)ip
   completion:(void(^)(BOOL isSuccess, NSError *error))completion
 ’
*/
+ (void)wifiConnect:(NSString *)wifiName
           password:(NSString *)password
         completion:(void(^)(NSString *ip, NSError *error))completion;

/**
 * @brief 通过ip地址连接wifi
 该方法需在打印机ip地址不为0.0.0.0时使用，表示打印机Wifi已配网
 如果手机连接的Wifi ip与打印机Wifi的ip不一致，则表示不在同一个局域网，需切换手机连接的wifi或重新配网
 * @param completion 回调是否成功及错误信息
 */
+ (void)wifiConnect:(NSString *)ip
         completion:(void(^)(BOOL isSuccess, NSError *error))completion;

/**
 * @brief 重设wifi
 * 重设IP失败回调错误信息
 * 重设IP成功会自动建立连接，无需再执行wifi连接，如果建立连接失败，会同时返回IP及Error
 * @param mac: 打印机蓝牙Mac地址
 * @param wifiName Wifi名称
 * @param password Wifi密码
 * @param completion 回调ip地址或重设Wifi错误信息
 */
+ (void)resetWifiWithMac:(NSString *)mac
         wifiName:(NSString *)wifiName
         password:(NSString *)password
       completion:(void(^)(NSString *ip, NSError *error))completion;

/**
 * brief 网络服务开启授权监听
 * @param success 授权成功，授权成功后再进行连接
 * @param failed 授权失败，在授权过程中或授权失败会重复回调，该回调谨慎处理
 */
+ (void)ipvServerOpen:(void(^) (void))isOpen
               failed:(void(^) (NSError *error))failed;
/**
 * @brief socket监听
 * @param ip IP地址
 * @param success 成功闭包
 * @param failed 失败闭包
 */
+ (void)socketPingStartWithIp:(NSString *)ip
                   success:(void(^) (void))success
                    failed:(void(^) (NSError *error))failed;
/**
 * @brief socket关闭监听
 */
+ (void)socketPingStop;

#pragma mark 获取打印机、标签信息
/**
 * @brief 获取当前连接打印机的信息
 * @param completion 打印机信息返回闭包
 */
+ (void)printerInfo:(void(^)(QYPrinterInfo *printInfo))completion;

/**
 * @brief 获取当前打印机装有的标签信息
 * @param completion 标签信息
 */
+ (void)currentLabelInfo:(void(^)(LabelInfo *labelInfo))completion;

/**
 * @brief 打印机回调
 * @param compltetion 回调类型
 */
+ (void)printerResponse:(void(^)(PrinterResponse exception))compltetion;

/**
 * @brief 打印机是否连接
 * 如下发打印/固件升级数据，需要先判断打印机是否已经连接
 * 可能存在断开蓝牙，或者打印机关机导致的打印机
 */
+ (BOOL)printerIsConnect;

#pragma mark 设置打印机信息

/**
 * @brief 设置纸张类型（临时修改，本次打印生效）
 * 如果打印机不支持设置的纸张类型，修改为间隙纸
 * @param parperType 纸张类型
 */
+ (void)setPrintParperType:(PaperType)parperType;


/**
 * @brief 设置打印浓度（临时修改，本次打印生效）
 * 值范围为0-15，如果小于0，则设置为0，大于15则设置为15
 * 值为0的时候，跟随打印机
 * @param darkness 浓度
 */
+ (void)setPrintDarkness:(int)darkness;

/**
 * @brief 设置打印速度（临时修改，本次打印生效）
 * 值范围为0-5，如果小于0则设置为0，大于5则设置为5
 * 值为0的时候，跟随打印机
 * @param speed 速度
 */
+ (void)setPrintSpeed:(int)speed;

/**
 * @brief 设置自动关机时间（设置1为5分钟，2为10分钟，依次类推）
 * 值范围0-255，如果小于0则设置为0，大于255则设置为255
 * @param time 时间
 */
+ (void)setAutoShutdownTime:(int)time;

/**
* @brief 设置打印浓度（永久修改，不建议频繁使用，会损坏打印机寿命）
* 值范围为0-15，如果小于0，则设置为0，大于15则设置为15
* 值为0的时候，跟随打印机
* @param darkness 浓度
*/
+ (void)setPrintDarknessForever:(int)darkness;

/**
* @brief 设置打印速度（永久修改，不建议频繁使用，会损坏打印机寿命）
* 值范围为0-5，如果小于0则设置为0，大于5则设置为5
* 值为0的时候，跟随打印机
* @param speed 速度
*/
+ (void)setPrintSpeedForever:(int)speed;

/**
 * @brief 打印设备信息，即打印自检页
 */
+ (void)printDeviceInfo;
#pragma mark 打印

/**
 * @brief 打印，需要绘制完标签才能调用
 * @param count 打印数量
 * @param completion 打印是否成功
 */
+ (void)print:(NSInteger)count
   completion:(void(^)(BOOL isSuccess))completion;

/**
 * @brief 打印，需要绘制完标签才能调用。B246D使用
 * @param count 打印数量
 * @param offsetX 打印x偏移，mm
 * @param offsetY 打印y偏移，mm
 * @param completion 打印是否成功
 */
+ (void)B246DPrint:(NSInteger)count
      offsetX:(CGFloat) offsetX
      offsetY:(CGFloat) offsetY
   completion:(void(^)(BOOL isSuccess))completion;

/**
 * @brief 自定义图片下发打印数据
 * @param image 打印图片
 * @param count 打印数量
 * @param dithering 是否开启抖动
 * @param completion 打印是否成功
 */
+ (void)printImage:(UIImage *)image
             count:(NSInteger)count
         dithering:(BOOL)dithering
        completion:(void(^)(BOOL isSuccess))completion;

/**
 * @brief 自定义图片下发打印数据。B246D使用
 * @param image 打印图片
 * @param count 打印数量
 * @param dithering 是否开启抖动
 * @param offsetX 打印x偏移，mm
 * @param offsetY 打印y偏移，mm
 * @param completion 打印是否成功
 */
+ (void)B246DPrintImage:(UIImage *)image
             count:(NSInteger)count
         dithering:(BOOL)dithering
           offsetX:(CGFloat) offsetX
           offsetY:(CGFloat) offsetY
        completion:(void(^)(BOOL isSuccess))completion;

/**
 * @brief 打印PDF图片
 * @param image 打印图片
 * @param count 打印数量
 * @param dithering 是否开启抖动
 * @param completion 打印是否成功
 */
+ (void)printPDFImage:(UIImage *)image
                count:(NSInteger)count
            dithering:(BOOL)dithering
           completion:(void(^)(BOOL isSuccess))completion;

/**
 * @brief 打印PDF图片。B246D使用
 * @param image 打印图片
 * @param count 打印数量
 * @param dithering 是否开启抖动
 * @param offsetX 打印x偏移，mm
 * @param offsetY 打印y偏移，mm
 * @param completion 打印是否成功
 */
+ (void)B246DPrintPDFImage:(UIImage *)image
                count:(NSInteger)count
            dithering:(BOOL)dithering
              offsetX:(CGFloat) offsetX
              offsetY:(CGFloat) offsetY
           completion:(void(^)(BOOL isSuccess))completion;

/**
 * @brief 取消打印
 */
+ (void)cancelPrint;

#pragma mark 固件升级
/**
 * @brief 固件升级
 * @param zipFilePath 固件zip包路径
 * @param compltetion 返回闭包，固件升级是否成功
 */
+ (void)updateFirmware:(NSString *)zipFilePath
           compltetion:(void(^)(BOOL isSuccess))compltetion;
/**
 * @brief 固件升级
 * @param logPath bin包路径
 * @param logPath log文件路径
 * @param compltetion 返回闭包，固件升级是否成功
 */
+ (void)updateFirmware:(NSString *)binPath
               logPath:(NSString *)logPath
           compltetion:(void(^)(BOOL isSuccess))compltetion;
/**
 * @brief 取消固件升级
 */
+ (void)cancelUpdateFirmware;


#pragma mark 绘制打印图片

/**
 * @brief 开始绘制
 * @param width 宽度，单位mm
 * @param height 高度，单位mm
 * @param orientation 打印方向(0:不旋转，90:顺时针旋转90度，180:旋转180度，270:顺时针旋转270)
 */
+ (void)startDrawWithWidth:(double)width
                    height:(double)height
               orientation:(int)orientation;

/**
 * @brief 预览图
 * completion 返回绘制的预览图
 */
+ (void)preView:(void(^)(UIImage *previewImage))completion;


#pragma mark 绘制文本
/**
 * @brief 绘制文本
 * @param textInfo 文本信息
 */
+ (void)drawText:(TextInfo *)textInfo;

/**
 * @brief 绘制条码
 * @param barcodeInfo 条码信息
 */
+ (void)drawBarcode:(BarcodeInfo *)barcodeInfo;

/**
 * @brief 绘制二维码
 * @param qrcodeInfo 二维码信息
 */
+ (void)drawQRCode:(QRCodeInfo *)qrcodeInfo;

/**
 * @brief 绘制图片
 * @param imageInfo 图片信息
 */
+ (void)drawImage:(ImageInfo *)imageInfo;

/**
 * @brief 绘制线条
 * @param lineInfo 线条信息
 */
+ (void)drawLine:(LineInfo *)lineInfo;

/**
 * @brief 绘制线框
 * shapeInfo 线框信息
 */
+ (void)drawShape:(ShapeInfo *)shapeInfo;

/**
 * @brief 下发打印词条
 * entries 词条(字符串数组)
 * region 按键
 */
+ (void)sendPrintEntries:(NSArray *)entries region:(NSInteger)region completion:(void(^)(BOOL sendSuccess))completion;

/**
 * @brief 获取直连设备
 * peripherals 直连设备数组
 */
+ (void)getSystemDirectDevice:(void(^)( NSArray<CBPeripheral *>*peripherals))completion;

/**
 * @brief 获取打印文本内容
 * text 文本内容
 */
+ (void)getPrintText:(void(^)(NSString *text))completion;

/**
 * @brief 重置词条
 */
+ (void)resetPrintEntries;

/**
 * @brief 设置机器日期
 * entries 词条(字符串数组)
 * region 按键
 */
+ (void)setPrinterDate:(NSInteger)year month:(NSInteger)month day:(NSInteger)day;

@end
