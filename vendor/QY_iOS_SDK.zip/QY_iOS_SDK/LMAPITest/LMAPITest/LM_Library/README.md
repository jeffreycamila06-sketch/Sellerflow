LMAPI说明文档

1.引用说明（OC项目）
1.1 在项目中拉入LM_Library，注意勾选Copy items if needed；
1.2 Build Settings->Other Link Flags添加-ObjC；

2.引用说明（Swift项目）
2.1 在项目中拉入LM_Library，注意勾选Copy items if needed；
2.2 Build Settings->Other Link Flags添加-ObjC；
2.3 添加OC桥接文件，Bridging-Header.h（可用通过创建OC文件快速添加）。
2.4 在桥接文件中导入LMAPI，#import "LMAPI.h"

注意事项：Release下请设置Active Architecture 为Yes，Build Settings->Build Active Architectures Only

3.蓝牙打印机相关说明
3.1 检查蓝牙状态
调用BLEStatus，检查蓝牙是否可用；
3.2 搜索打印机
调用scanPrinter，搜索蓝牙打印机设备；
3.3 连接打印机
调用connectPrinter，该方法通过打印机名称进行连接；
调用connectPrinterWithMac，该方法通过蓝牙MAC地址连接；
3.4 查询打印机信息
调用printerInfo，获取打印机信息
3.5 查询当前打印机耗材（即标签纸张信息，特定机型适用）
调用currentLabelInfo，获取耗材信息
3.6 打印机主动回调
调用printerResponse，打印机主动回调信息，如缺纸
3.6 打印机相关设置
例如设置纸张类型：调用setPrintParperType

4.打印说明
打印需确保打印机当前由纸张，关盖状态
打印前需绘制内容，调用startDrawWithWidth，设置标签大小及打印方向
绘制完成后调用print完成打印

例如打印文本：
OC:

// 开始绘制，标签大小40mm*30mm，打印方向：水平
[LMAPI startDrawWithWidth:40 height:30 orientation:0];

// 文本位置及方向
ElementLocation *textLocation = [[ElementLocation alloc] init];
textLocation.x = 0;
textLocation.y = 200;
textLocation.width = 320;
textLocation.height = 35;
// 文本信息
TextInfo *textInfo = [[TextInfo alloc] init];
textInfo.location = textLocation;
textInfo.fontSize = 30;
textInfo.text = @"珠海趣印科技有限公司";
textInfo.aligment = TextAligmentCenter;
[LMAPI drawText:textInfo];

// 打印标签
[LMAPI print:1 completion:^(BOOL isSuccess) {

}];


Swift:
// 开始绘制，标签大小40mm*30mm，打印方向：水平
LMAPI.startDraw(withWidth: 40, height: 30, orientation: 0)

// 绘制文本
// 文本大小及方向
let textLocation = ElementLocation()
textLocation.x = 0
textLocation.y = 200
textLocation.width = 320
textLocation.height = 35
// 文本信息
let textInfo = TextInfo()
textInfo.location = textLocation
textInfo.fontSize = 30
textInfo.text = "珠海趣印科技有限公司"
textInfo.aligment = .center
LMAPI.drawText(textInfo)
LMAPI.print(1) { (isSuccess) in

}

5.Wifi连接
5.1 判断设备是否属于Wifi类型
蓝牙获取外设BLEPeripheral信息，提供参数isWiFiPeripheral，用于判断是否Wifi类型，如果是，通过遗下步骤进行连接Wifi。
5.2 通过打印机设备Mac地址获取IP地址
[LMAPI getIpWithMac:device.mac completion:^(NSString *ip, NSError *error) { 

}]
如果获取的IP地址为0.0.0.0则表示打印机Wifi模块未配网，需进行配网
如果获取的IP地址非0.0.0.0则表示打印机Wifi模块以配网，可以通过IP地址进行连接
建议：如果IP地址非为0.0.0.0可以将Mac地址及IP地址缓存本地，下次在设备列表中找到该Mac地址的设备，可以通过IP直接连接，无需查询IP地址
5.3 已配网的情况下通过IP进行连接
[LMAPI wifiConnect:ip completion:^(BOOL isSuccess, NSError *error) {

}]
5.4 扫描Wifi
[self scanWifi:^(NSArray *wifiArray) {

}]
SDK提供打印机Wifi模块扫描周边Wifi的方法

