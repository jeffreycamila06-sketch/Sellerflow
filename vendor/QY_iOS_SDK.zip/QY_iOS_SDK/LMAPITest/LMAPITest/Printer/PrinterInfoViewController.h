//
//  PrinterInfoViewController.h
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "BaseViewController.h"


@protocol PrinterInfoViewControllerDelegate <NSObject>

-(void)disConnectDevice;

@end

NS_ASSUME_NONNULL_BEGIN

@interface PrinterInfoViewController : BaseViewController

@property (nonatomic, weak) id <PrinterInfoViewControllerDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
