//
//  PrinterInfoViewController.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "PrinterInfoViewController.h"
#import "LMAPI.h"
#import "PrinterSetViewController.h"
#import "XHudManager.h"

@interface PrinterInfoViewController() <UITableViewDelegate, UITableViewDataSource>

@property(nonatomic, strong) NSArray *titles;
@property(nonatomic, strong) UITableView *tab;
@property(nonatomic, strong) QYPrinterInfo *printerInfo;
@property(nonatomic, strong) LabelInfo *labelInfo;

@property(nonatomic, strong) UIButton *deleteButton;
@end

@implementation PrinterInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"设备管理";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"设置" style:UIBarButtonItemStyleDone target:self action:@selector(navigationRightItemAction)];
    
    _titles = @[@"设备名称", @"MAC", @"固件版本号", @"SN", @"剩余电量",@"自动关机时间",
                @"DPI", @"最大打印宽度", @"RFID碳带序列号", @"RFID耗材序列号", @"RFID色带序列号",
                @"碳带余量", @"色带余量", @"纸张余量"];

    _tab = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, X_Width, X_Height-70)];
    _tab.tableFooterView = [UIView new];
    _tab.delegate = self;
    _tab.dataSource = self;
    [_tab registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.view addSubview:_tab];
    
    _deleteButton = [[UIButton alloc] initWithFrame:CGRectMake(15, X_Height-60, X_Width-30, 50)];
    [_deleteButton setTitle:@"删除设备" forState:UIControlStateNormal];
    _deleteButton.titleLabel.font = [UIFont systemFontOfSize:17];
    [_deleteButton setTintColor:UIColor.whiteColor];
    _deleteButton.backgroundColor = UIColor.blackColor;
    _deleteButton.layer.cornerRadius = 5;
    [_deleteButton addTarget:self action:@selector(deleteButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_deleteButton];
    
    
    [XHudManager.sharedInstance show:@"正在查询打印机及标签信息"];
    
    [LMAPI printerInfo:^(QYPrinterInfo *printInfo) {
        self.printerInfo = printInfo;
        [self.tab reloadData];
        [XHudManager.sharedInstance hidden];
    }];
    
    [LMAPI currentLabelInfo:^(LabelInfo *labelInfo) {
        self.labelInfo = labelInfo;
        [self.tab reloadData];
        
    }];
    
    
}



- (void)navigationRightItemAction {
    
    PrinterSetViewController *setVC = [[PrinterSetViewController alloc] init];
    setVC.view.backgroundColor = UIColor.whiteColor;
    setVC.printerInfo = self.printerInfo;
    [self.navigationController pushViewController:setVC animated:true];
}

- (void)deleteButtonAction {
    
    UIAlertController *alter = [UIAlertController alertControllerWithTitle:@"是否删除设备" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alter dismissViewControllerAnimated:YES completion:nil];
        
    }];
    [alter addAction:cancel];
    UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alter dismissViewControllerAnimated:YES completion:nil];
        [LMAPI disConnectPrinter:^(BOOL isSuccess) {
         
        }];
        [self.delegate disConnectDevice];
        
        [self.navigationController popViewControllerAnimated:true];
    }];
    [alter addAction:confirm];
    
    [UIApplication.sharedApplication.keyWindow.rootViewController presentViewController:alter animated:YES completion:nil];
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _titles.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 44;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%@", _titles[indexPath.row], self.printerInfo.deviceName];
            break;
        case 1:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%@", _titles[indexPath.row], self.printerInfo.mac];
            break;
        case 2:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%@", _titles[indexPath.row], self.printerInfo.firmwareVersion];
            break;
        case 3:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%@", _titles[indexPath.row], self.printerInfo.deviceID];
            break;
        case 4:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%d", _titles[indexPath.row], self.printerInfo.remainingBattery];
            break;
        case 5:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%d分钟", _titles[indexPath.row], self.printerInfo.shutdownTime];
            break;
        case 6:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%dDPI", _titles[indexPath.row], self.printerInfo.deviceDPI];
            break;
        case 7:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%dmm", _titles[indexPath.row], self.printerInfo.maxPrintWidth];
            break;
        case 8:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%@", _titles[indexPath.row], self.printerInfo.ttfNumber];
            break;
        case 9:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%@", _titles[indexPath.row], self.labelInfo.paperNumber];
            break;
        case 10:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%@", _titles[indexPath.row], self.printerInfo.ribbonNumber];
            break;
        case 11:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%dmm", _titles[indexPath.row], self.printerInfo.ttfOverlength];
            break;
        case 12:
            cell.textLabel.text = [NSString stringWithFormat:@"%@：%dmm", _titles[indexPath.row], self.printerInfo.ribbonOverlength];
            break;
        case 13:
            if (self.labelInfo.paperType == PaperTypeContinuous) {
                cell.textLabel.text = [NSString stringWithFormat:@"%@：%dmm", _titles[indexPath.row], self.labelInfo.overlength];
            }else {
                cell.textLabel.text = [NSString stringWithFormat:@"%@：%d张", _titles[indexPath.row], self.labelInfo.remainingCount];
            }
            
            break;
        
        default:
            break;
    }
    return cell;
}
@end
