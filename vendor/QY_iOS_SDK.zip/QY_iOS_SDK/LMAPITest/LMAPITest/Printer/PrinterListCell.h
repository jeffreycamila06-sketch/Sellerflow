//
//  PrinterListCell.h
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PrinterListCell : UITableViewCell

@property(nonatomic, strong) UILabel *nameLb;

@property(nonatomic, strong) UILabel *macLb;

@end

NS_ASSUME_NONNULL_END
