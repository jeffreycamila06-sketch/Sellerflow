//
//  PrinterListCell.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "PrinterListCell.h"

@interface PrinterListCell()



@end


@implementation PrinterListCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _nameLb = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, self.frame.size.width-30, 25)];
        _macLb = [[UILabel alloc] initWithFrame:CGRectMake(15, 25, self.frame.size.width-30, 25)];
        
        _nameLb.font = [UIFont systemFontOfSize:15];
        _macLb.font = [UIFont systemFontOfSize:15];
        _nameLb.textColor = [UIColor blackColor];
        _macLb.textColor = [UIColor blackColor];
        [self addSubview:_nameLb];
        [self addSubview:_macLb];
    }
    return self;
}

@end
