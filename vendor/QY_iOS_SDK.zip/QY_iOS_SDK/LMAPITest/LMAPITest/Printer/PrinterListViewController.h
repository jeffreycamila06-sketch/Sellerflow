//
//  PrinterListViewController.h
//  LMAPITest
//
//  Created by YFB-CDS on 2020/7/16.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "BaseViewController.h"


@interface PrinterListViewController : BaseViewController


@property(nonatomic, assign) BOOL BLECanUse;

@end

