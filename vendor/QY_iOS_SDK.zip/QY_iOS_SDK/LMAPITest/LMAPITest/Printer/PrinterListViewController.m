//
//  PrinterListViewController.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/7/16.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "PrinterListViewController.h"
#import "LMAPI.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "XHudManager.h"
#import "Constant.h"
#import "PrinterListCell.h"
#import "PrinterInfoViewController.h"
#import "FuncListViewController.h"
#import "XSingleView.h"

@interface PrinterListViewController () <UITableViewDelegate, UITableViewDataSource, PrinterInfoViewControllerDelegate>

@property(nonatomic, strong) UITableView *tableView;

@property(nonatomic, strong) NSArray *devices;

@property(nonatomic, strong) QYPrinterInfo *printInfo;

@property(nonatomic, strong) BLEPeripheral * peripheral;

@end

@implementation PrinterListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"趣印科技";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"搜索" style:UIBarButtonItemStyleDone target:self action:@selector(scan)];
    
    
    _printInfo = [[QYPrinterInfo alloc] init];
    _devices = [[NSArray alloc] init];
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.tableView registerClass:[PrinterListCell class] forCellReuseIdentifier:@"cell"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];

    [LMAPI BLEStatus:^(BLEStatus state) {
        self.BLECanUse = (state == BLEStatusPoweredOn) ? YES : NO;
        [self scan];
    }];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [LMAPI stopScan];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationItem.leftBarButtonItem = nil;
}

- (void)scan {
    if (!self.BLECanUse) {
        [XSingleView.sharedInstance show:@"蓝牙不可用"];
    }
    if (self.BLECanUse) {
        if (![LMAPI printerIsConnect]) {
            [LMAPI scanPrinter:^(NSArray *printers) {
                self.devices = printers;
                [self BluetoothDirectConnection];
                [self.tableView reloadData];
            }];
        }
        
    }
}
///获取蓝牙直连设备
-(void)BluetoothDirectConnection{
    
    [LMAPI getSystemDirectDevice:^(NSArray<CBPeripheral *> *peripherals) {
        for (CBPeripheral*periphera in  peripherals) {
            if ([periphera.name containsString:@"AM-243Z"]) {
                for (BLEPeripheral *device in  self.devices) {
                    if (device.peripheral.name == periphera.name) {
                        [self connectDevice:device];
                    }
                }
            }
        }
    }];
}


- (void)shareLogFileWithURL:(NSURL *)fileURL fromViewController:(UIViewController *)viewController {
    if (fileURL) {
        UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:@[fileURL] applicationActivities:nil];
        [viewController presentViewController:activityVC animated:YES completion:nil];
    }
}

#pragma mark UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        return 1;
    }else {
        return self.devices.count;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PrinterListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (indexPath.section == 0) {
        cell.nameLb.text = [NSString stringWithFormat:@"打印机名称：%@", self.printInfo.deviceName];
        cell.macLb.text = [NSString stringWithFormat:@"MAC：%@", self.printInfo.mac];
    }else {
        BLEPeripheral *device = self.devices[indexPath.row];
        cell.nameLb.text = [NSString stringWithFormat:@"打印机名称：%@", device.peripheral.name];
        cell.macLb.text = [NSString stringWithFormat:@"MAC：%@", device.mac];
    }
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        // 前往详情
        PrinterInfoViewController *printInfoVC = [[PrinterInfoViewController alloc] init];
        printInfoVC.view.backgroundColor = UIColor.whiteColor;
        printInfoVC.delegate = self;
        [self.navigationController pushViewController:printInfoVC animated:YES];
        [tableView reloadData];
    }else {
        
        // 连接打印机
        BLEPeripheral *device = self.devices[indexPath.row];
        [self connectDevice:device];
        
        
    }
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, X_Width, 30)];
    headerView.backgroundColor = UIColor.lightGrayColor;
    UILabel *titleLb = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, X_Width-30, 30)];
    titleLb.font = [UIFont systemFontOfSize:15];
    titleLb.textColor = UIColor.blackColor;
    [headerView addSubview:titleLb];
    if (section == 0) {
        titleLb.text = @"当前连接的打印";
    }else {
        titleLb.text = @"搜索到的打印";
    }
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 30;
}


- (void)disConnectDevice {
    self.printInfo.deviceName = @"";
    self.printInfo.mac = @"";
    [self.tableView reloadData];
}

- (void)queryInfo {
    [XHudManager.sharedInstance hidden];
    // 前往功能列表
    FuncListViewController *funcListVC = [[FuncListViewController alloc] init];
    funcListVC.peripheral = self.peripheral;
    [self.navigationController pushViewController:funcListVC animated:YES];
}

- (void)connectDevice:(BLEPeripheral *)device {
    if (device.isWiFiPeripheral) {
        // 检查网络授权
//        NSDictionary *router = [LDSRouterInfo getRouterInfo];
        NSString *ip = @"https://www.baidu.com";
        if (ip == nil) {
            return;
        }
        [LMAPI ipvServerOpen:^{
            [self wifiConnect:device];

        } failed:^(NSError *error) {
            NSLog(@"%@", error);

        }];

    }else {
        if (device.mac) {
            [self bleConnect:device];
        }else {
            [self dictBleContent:device];
        }
//        [self bleConnect:device];
        self.peripheral = device;
    }
}

-(void)dictBleContent:(BLEPeripheral *)device  {

    [XHudManager.sharedInstance show:@"正在连接打印机..."];
    [LMAPI connectPrinter:device.peripheral.name completion:^(BOOL isSuccess) {
        if (isSuccess) {
            self.printInfo.deviceName = device.peripheral.name;
//            self.printInfo.mac = device.mac;
            [self.tableView reloadData];
            
            if ([UIApplication.sharedApplication keyWindow].rootViewController.presentedViewController != nil) {
                [UIApplication.sharedApplication.keyWindow.rootViewController dismissViewControllerAnimated:true completion:^{
                    [self queryInfo];
                }];
            }else {
                [self queryInfo];
            }
            
            
        }else {
            // 连接失败
            self.printInfo.deviceName = @"";
            self.printInfo.mac = @"";
            [self.tableView reloadData];
            [XHudManager.sharedInstance hidden];
            [XSingleView.sharedInstance show:@"连接失败"];
            // 如果不是当前视图，重新更新Root
            if (self.navigationController.visibleViewController != self) {
                // 重新更新Root
                PrinterListViewController *rootVC = [[PrinterListViewController alloc] init];
                [[UIApplication sharedApplication] keyWindow].rootViewController = [[UINavigationController alloc] initWithRootViewController:rootVC];
            }
        }
    }];
}

- (void)bleConnect:(BLEPeripheral *)device {
    [XHudManager.sharedInstance show:@"正在连接打印机..."];
    [LMAPI connectPrinterWithMac:device.mac completion:^(BOOL isSuccess) {
        if (isSuccess) {
            self.printInfo.deviceName = device.peripheral.name;
            self.printInfo.mac = device.mac;
            [self.tableView reloadData];
            
            if ([UIApplication.sharedApplication keyWindow].rootViewController.presentedViewController != nil) {
                [UIApplication.sharedApplication.keyWindow.rootViewController dismissViewControllerAnimated:true completion:^{
                    [self queryInfo];
                }];
            }else {
                [self queryInfo];
            }
            
            
        }else {
            // 连接失败
            self.printInfo.deviceName = @"";
            self.printInfo.mac = @"";
            [self.tableView reloadData];
            [XHudManager.sharedInstance hidden];
            [XSingleView.sharedInstance show:@"连接失败"];
            // 如果不是当前视图，重新更新Root
            if (self.navigationController.visibleViewController != self) {
                // 重新更新Root
                PrinterListViewController *rootVC = [[PrinterListViewController alloc] init];
                [[UIApplication sharedApplication] keyWindow].rootViewController = [[UINavigationController alloc] initWithRootViewController:rootVC];
            }
            
            
        }
        
        
    }];
}

- (void)wifiConnect:(BLEPeripheral *)device {
    // 查询IP
    [XHudManager.sharedInstance show:@"正在连接打印机..."];
    [LMAPI getIpWithMac:device.mac completion:^(NSString *ip, NSError *error) {
        
        if (ip == nil) {
            [XHudManager.sharedInstance hidden];
            [XSingleView.sharedInstance show:error.description];
            [self.tableView reloadData];
            return;
        }
        if ([ip isEqualToString:@"0.0.0.0"]) {
            // 如果IP为“0.0.0.0”，表示未配网，需进行配网
            // 查询周边的Wifi
            // 一般是通过手机获取当前连接的Wifi输入密码进行配对
            // SDK开放扫描的周边的方法，需要时才使用
//            [self scanWifi:^(NSArray *wifiArray) {
                // 根据Wifi名称、密码进行配网
                NSString *wifiName = @"YFB";
                NSString *wifiPassword = @"yfb@1234";
                [LMAPI wifiConnect:wifiName password:wifiPassword completion:^(NSString *ip, NSError *error) {
                    [XHudManager.sharedInstance hidden];
                    [self.tableView reloadData];
                    if (ip != nil && error != nil) {
                        [self queryInfo];
                        
                        [LMAPI socketPingStartWithIp:ip success:^{
                            NSLog(@"建立监听成功");
                        } failed:^(NSError *error) {
                            NSLog(@"Socket断开连接");
                        }];
                    }else if (error != nil) {
                        [XSingleView.sharedInstance show:error.description];
                    }
                   
                }];
//            }];
            
        }else {
            // 已配网
            // 建立连接
            [LMAPI wifiConnect:ip completion:^(BOOL isSuccess, NSError *error) {
                [XHudManager.sharedInstance hidden];
                [self.tableView reloadData];
                // 连接成功，查询设备信息
                if (isSuccess) {
                    [self queryInfo];
                    // Socket监听
                    [LMAPI socketPingStartWithIp:ip success:^{
                        NSLog(@"建立监听成功");
                    } failed:^(NSError *error) {
                        NSLog(@"Socket断开连接");
                    }];
                }else {
                    [XSingleView.sharedInstance show:error.description];
                }
            }];
        }
        
    }];
}

- (void)scanWifi:(void(^)(NSArray *wifiArray))wifiArray {
    [LMAPI scanWifi:wifiArray];
}


@end
