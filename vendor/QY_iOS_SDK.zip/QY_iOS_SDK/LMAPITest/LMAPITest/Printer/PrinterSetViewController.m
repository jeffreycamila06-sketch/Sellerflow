//
//  PrinterSetViewController.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "PrinterSetViewController.h"
#import "PrinterLabelTypeViewController.h"
#import "PrinterConViewController.h"
#import "PrinterConViewController.h"
#import "PrinterSpeedViewController.h"
#import "PrinterSDTimeViewController.h"
#import "XHudManager.h"
#import "XSingleView.h"
#import "AppDelegate.h"
#import "SSZipArchive.h"
#import "AFNetworking.h"
@interface PrinterSetViewController()<UITableViewDelegate, UITableViewDataSource>


@property(nonatomic, strong) UITableView *tab;

@property(nonatomic, strong) NSArray *titles;

@end

@implementation PrinterSetViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"设置";
    
    _titles = @[@"设置纸张类型（临时修改）", @"设置打印浓度（临时修改）", @"设置打印速度（临时修改）",
                @"设置打印浓度（永久修改）", @"设置打印速度（永久修改）", @"设置关机时间", @"打印自检页", @"固件更新", @"重设IP"];
    
    _tab = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, X_Width, X_Height)];
    _tab.tableFooterView = [UIView new];
    _tab.delegate = self;
    _tab.dataSource = self;
    [_tab registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.view addSubview:_tab];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _titles.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 44;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = self.titles[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 
    if (indexPath.row == 0) {
        PrinterLabelTypeViewController *vc = [[PrinterLabelTypeViewController alloc] init];
        vc.title = self.titles[indexPath.row];
        vc.view.backgroundColor = UIColor.whiteColor;
        [self.navigationController pushViewController:vc animated:true];
    }else if (indexPath.row == 1 || indexPath.row == 3) {
        PrinterConViewController *vc = [[PrinterConViewController alloc] init];
        vc.title = self.titles[indexPath.row];
        vc.isForever = indexPath.row == 1 ? false : true;
        vc.view.backgroundColor = UIColor.whiteColor;
        [self.navigationController pushViewController:vc animated:true];
    }else if (indexPath.row == 2 || indexPath.row == 4) {
        PrinterSpeedViewController *vc = [[PrinterSpeedViewController alloc] init];
        vc.title = self.titles[indexPath.row];
        vc.isForever = indexPath.row == 2 ? false : true;
        vc.view.backgroundColor = UIColor.whiteColor;
        [self.navigationController pushViewController:vc animated:true];
    }else if (indexPath.row == 5) {
        PrinterSDTimeViewController *vc = [[PrinterSDTimeViewController alloc] init];
        vc.title = self.titles[indexPath.row];
        vc.view.backgroundColor = UIColor.whiteColor;
        [self.navigationController pushViewController:vc animated:true];
    }else if (indexPath.row == 6){
        [LMAPI printDeviceInfo];
    }else if (indexPath.row == 7) {
        
//        AppDelegate *delegate = (AppDelegate *)UIApplication.sharedApplication.delegate;
//        if (delegate.coverIsOpen) {
//            [XSingleView.sharedInstance show:@"纸仓盖打开"];
//            return;
//        }
//        if (delegate.outofPaper) {
//            [XSingleView.sharedInstance show:@"打印机缺纸"];
//            return;
//        }
//        NSString *filePath = @"";
//        NSBundle *bundle = [NSBundle bundleForClass:[self class]];
//
//        if ([self.printerInfo.deviceID hasPrefix:@"Q124C"]) {
//            filePath = [bundle pathForResource:@"Q124_1.1.9_" ofType:@"zip"];
//            [self upgradeToFirmwareVersion:filePath];
//        } else if ([self.printerInfo.deviceID hasPrefix:@"Q109"]) {
//            filePath = [bundle pathForResource:@"Q109" ofType:@"zip"];
//            [self upgradeToFirmwareVersion:filePath];
//        } else if ([self.printerInfo.deviceID hasPrefix:@"Q210"]) {
//            filePath = [bundle pathForResource:@"Q210" ofType:@"zip"];
//            [self upgradeToFirmwareVersion:filePath];
//        } else if ([self.printerInfo.deviceID hasPrefix:@"Q371"]) {
//            [self showFirmwareVersionSelectionAlert];
//        } else {
//            [XSingleView.sharedInstance show:@"未有该设备固件"];
//            [tableView reloadData];
//            return;
//        }
        


        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"选择固件版本" message:nil preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *version1Action = [UIAlertAction actionWithTitle:@"Q417_1_1_2" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            // 用户选择了升级到 "Q417_1_1_2" 版本
            NSString * urlStr = @"https://oss-test.qu-in.com/quinSystem/file/device/firmware/642147040247287808_Q417_1_1_2.zip";
            [self upgradeToHttpsFirmware:urlStr version:@"1.1.2"];
        }];
        
        UIAlertAction *version2Action = [UIAlertAction actionWithTitle:@"1.0.8" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //https://oss-test.qu-in.com/quinSystem/file/device/firmware/642147495710953472_Q417_1_1_1.zip
            // 用户选择了升级到 "1.0.1" 版本
            NSString * urlStr = @"https://oss-test.qu-in.com/quinSystem/file/device/firmware/642827111920439296_Q417_1_0_8.zip";
            [self upgradeToHttpsFirmware:urlStr version:@"1.0.8"];
        }];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        
        [alertController addAction:version1Action];
        [alertController addAction:version2Action];
        [alertController addAction:cancelAction];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
        
        
    }else if (indexPath.row == 8) {
        
        NSString *mac = self.printerInfo.mac;

        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"输入WiFi信息" message:nil preferredStyle:UIAlertControllerStyleAlert];

        [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = @"WiFi名称";
        }];

        [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = @"WiFi密码";
            textField.secureTextEntry = YES;
        }];

        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        [alertController addAction:cancelAction];

        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            UITextField *wifiNameTextField = alertController.textFields[0];
            UITextField *wifiPasswordTextField = alertController.textFields[1];
            
            NSString *wifiName = wifiNameTextField.text;
            NSString *wifiPassword = wifiPasswordTextField.text;
            
            [XHudManager.sharedInstance show:@"正在重设Wifi"];
            [LMAPI resetWifiWithMac:mac wifiName:wifiName password:wifiPassword completion:^(NSString *ip, NSError *error) {
                [XHudManager.sharedInstance hidden];
                if (ip != nil) {
                    [XSingleView.sharedInstance show:[NSString stringWithFormat:@"重设Wifi成功\nIP地址:%@", ip]];
                    if (error != nil) {
                        [XSingleView.sharedInstance show:[NSString stringWithFormat:@"建立连接失败\n错误:%@", error.description]];
                    }
                }else {
                    [XSingleView.sharedInstance show:[NSString stringWithFormat:@"重设Wifi失败\nError:%@", error.description]];
                }
            }];
        }];

        [alertController addAction:confirmAction];

        // 在适当的位置显示弹窗
        [self presentViewController:alertController animated:YES completion:nil];

    }
    [tableView reloadData];
}

- (void)unzip:(NSString *)zipFilePath completetion:(void(^)(NSString *binPath, NSString *logPath))compltetion {
    // 文件不存在
    if (![[NSFileManager defaultManager] fileExistsAtPath:zipFilePath]) {
        compltetion(NULL, NULL);
        return;
    }
    NSString *documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *zipPath = [NSString stringWithFormat:@"%@%@", documentPath, @"/FirmwareZip"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:zipFilePath]) {
        [[NSFileManager defaultManager] removeItemAtPath:zipPath error:nil];
    }
    [[NSFileManager defaultManager] createDirectoryAtPath:zipPath withIntermediateDirectories:YES attributes:nil error:nil];
    [SSZipArchive unzipFileAtPath:zipFilePath toDestination:zipPath progressHandler:nil completionHandler:^(NSString *path, BOOL succeeded, NSError *error) {
        if (succeeded) {
            // 解压成功
            NSString *binFilePath = @"";
            NSString *logFilePath = @"";
            NSArray *fileNames = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:zipPath error:nil];
            NSString *fileName = @"";
            // bin文件及log文件路径
            for (int i = 0; i < fileNames.count; i++) {
                fileName = fileNames[i];
                if ([fileName hasSuffix:@".log"]) {
                    logFilePath = [NSString stringWithFormat:@"%@/%@", zipPath, fileName];
                }
                if ([fileName hasSuffix:@".bin"]) {
                    binFilePath = [NSString stringWithFormat:@"%@/%@", zipPath, fileName];
                }
            }
            if (logFilePath.length > 0 && binFilePath.length > 0) {
                compltetion(binFilePath, logFilePath);
                
            }else {
                compltetion(NULL ,NULL);
            }
            
        }else {
            // 解压失败
            compltetion(NULL ,NULL);
        }
    }];
}

- (void)showFirmwareVersionSelectionAlert {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"选择固件版本" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *version1Action = [UIAlertAction actionWithTitle:@"0.0.7" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        // 用户选择了升级到 "0.0.7" 版本
        NSString *filePath = @"";
        NSBundle *bundle = [NSBundle bundleForClass:[self class]];
        filePath = [bundle pathForResource:@"0.0.7" ofType:@"zip"];

        [self upgradeToFirmwareVersion:filePath];
    }];
    
    UIAlertAction *version2Action = [UIAlertAction actionWithTitle:@"1.0.1" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        // 用户选择了升级到 "1.0.1" 版本
        NSString *filePath = @"";
        NSBundle *bundle = [NSBundle bundleForClass:[self class]];
        filePath = [bundle pathForResource:@"1.0.1" ofType:@"zip"];
        
        [self upgradeToFirmwareVersion:filePath];
    }];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alertController addAction:version1Action];
    [alertController addAction:version2Action];
    [alertController addAction:cancelAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)upgradeToFirmwareVersion:(NSString *)filePath {
    [LMAPI setLogStatus:YES];
    [XHudManager.sharedInstance show:@"正在更新固件"];
    [LMAPI updateFirmware:filePath compltetion:^(BOOL isSuccess) {
        if (isSuccess) {
            [XSingleView.sharedInstance show:@"升级成功"];
        }else {
            [XSingleView.sharedInstance show:@"升级失败"];
        }
        [XHudManager.sharedInstance hidden];
    }];
}

- (void)upgradeToHttpsFirmware:(NSString *)urlStr version: (NSString *)version {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", version]];
    path = [NSString stringWithFormat:@"%@.zip",path];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURL *url = [NSURL URLWithString:urlStr];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];

    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
        NSLog(@"下载进度：%.0f％", downloadProgress.fractionCompleted * 100);
        dispatch_async(dispatch_get_main_queue(), ^{
//            weakself.progressView.progress = downloadProgress.fractionCompleted; //如果需要进行UI操作，需要获取主线程进行操作
        });

    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        dispatch_async(dispatch_get_main_queue(), ^{
            //如果需要进行UI操作，需要获取主线程进行操作
        });
        /* 设定下载到的位置 */
        return [NSURL fileURLWithPath:path];

    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        NSLog(@"下载完成%@",response);

        [self unzip:path completetion:^(NSString *binPath, NSString *logPath) {
            if (binPath.length > 0 && logPath.length > 0) {
                if ([LMAPI printerIsConnect]) {
                    [LMAPI updateFirmware:binPath logPath:logPath compltetion:^(BOOL isSuccess) {
                        if (isSuccess) {
                            [XSingleView.sharedInstance show:@"升级成功"];
                        }
                        else{
                            [XSingleView.sharedInstance show:@"升级失败"];
                        }
                    }];
                }
            }
        }];


    }];
    [downloadTask resume];
}

@end
