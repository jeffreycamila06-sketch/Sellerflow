//
//  PrinterConViewController.h
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PrinterConViewController : BaseViewController

@property(nonatomic, assign) BOOL isForever;

@end

NS_ASSUME_NONNULL_END
