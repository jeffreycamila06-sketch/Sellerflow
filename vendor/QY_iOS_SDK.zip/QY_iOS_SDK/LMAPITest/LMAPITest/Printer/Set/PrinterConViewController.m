//
//  PrinterConViewController.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "PrinterConViewController.h"
#import "LMAPI.h"
#import "XSingleView.h"
@interface PrinterConViewController ()

@property(nonatomic, strong) UIView *bgView;

@property(nonatomic, strong) UILabel *titleLb;

@property(nonatomic, strong) UITextField *tf;

@property(nonatomic, strong) UIButton *changeButton;

@end

@implementation PrinterConViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    _bgView = [[UIView alloc] initWithFrame:CGRectMake(0, self.X_NavHeight, X_Width, 50)];
    _bgView.backgroundColor = UIColor.whiteColor;
    [self.view addSubview:_bgView];
    
    _titleLb = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 150, 50)];
    _titleLb.font = [UIFont systemFontOfSize:15];
    _titleLb.textColor = UIColor.blackColor;
    _titleLb.text = @"打印浓度（1-15）";
    [_bgView addSubview:_titleLb];
    
    _tf = [[UITextField alloc] initWithFrame:CGRectMake(X_Width-120, 0, 105, 50)];
    _tf.font = [UIFont systemFontOfSize:12];
    _tf.textAlignment = NSTextAlignmentRight;
    _tf.keyboardType = UIKeyboardTypeNumberPad;
    _tf.textColor = UIColor.blackColor;
    _tf.placeholder = @"请输入打印浓度";
    _tf.returnKeyType = UIReturnKeyDone;
    [_bgView addSubview:_tf];
    
    _changeButton = [[UIButton alloc] initWithFrame:CGRectMake(15, X_Height-60, X_Width-30, 50)];
    [_changeButton setTitle:@"修改" forState:UIControlStateNormal];
    _changeButton.titleLabel.font = [UIFont systemFontOfSize:17];
    [_changeButton setTintColor:UIColor.whiteColor];
    _changeButton.backgroundColor = UIColor.blackColor;
    _changeButton.layer.cornerRadius = 5;
    [_changeButton addTarget:self action:@selector(changeButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_changeButton];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(endEdit)];
    [self.view addGestureRecognizer:tap];
}


- (void)endEdit {
    [self.view endEditing:true];
}

- (void)changeButtonAction {
    
    if (_tf.text) {
        if (self.isForever) {
            [LMAPI setPrintDarknessForever:[_tf.text intValue]];
        }else {
            [LMAPI setPrintDarkness:[_tf.text intValue]];
        }
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
        
    }
}

@end
