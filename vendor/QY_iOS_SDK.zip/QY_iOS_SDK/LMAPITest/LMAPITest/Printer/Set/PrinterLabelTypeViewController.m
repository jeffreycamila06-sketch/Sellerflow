//
//  PrinterLabelTypeViewController.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "PrinterLabelTypeViewController.h"
#import "LMAPI.h"
#import "XSingleView.h"

@interface PrinterLabelTypeViewController ()<UITableViewDelegate, UITableViewDataSource>

@property(nonatomic, strong) UITableView *tab;

@property(nonatomic, strong) NSArray *titles;

@end

@implementation PrinterLabelTypeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _titles = @[@"设置为连续纸", @"设置为间隙纸", @"设置为黑标纸"];
    
    _tab = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, X_Width, X_Height)];
    _tab.tableFooterView = [UIView new];
    _tab.delegate = self;
    _tab.dataSource = self;
    [_tab registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.view addSubview:_tab];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _titles.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 44;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.textLabel.text = self.titles[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    switch (indexPath.row) {
        case 0:
            [LMAPI setPrintParperType:PaperTypeContinuous];
            break;
        case 1:
            [LMAPI setPrintParperType:PaperTypeInterval];
            break;
        case 2:
            [LMAPI setPrintParperType:PaperTypeBlackLabel];
            break;
            
        default:
            break;
    }
    [XSingleView.sharedInstance show:@"修改成功"];
    [self.navigationController popViewControllerAnimated:YES];
    [tableView reloadData];
    
}

@end
