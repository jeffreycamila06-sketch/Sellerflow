//
//  PrinterSDTimeViewController.m
//  LMAPITest
//
//  Created by YFB-CDS on 2020/8/21.
//  Copyright © 2020 YFB-CDS. All rights reserved.
//

#import "PrinterSDTimeViewController.h"
#import "LMAPI.h"
#import "XSingleView.h"
@interface PrinterSDTimeViewController ()

@property(nonatomic, strong) UIView *bgView;

@property(nonatomic, strong) UILabel *titleLb;

@property(nonatomic, strong) UITextField *tf;

@property(nonatomic, strong) UIButton *changeButton;

@property(nonatomic, strong) UILabel *minuteLb;

@end

@implementation PrinterSDTimeViewController


- (void)viewDidLoad {
    [super viewDidLoad];

    _bgView = [[UIView alloc] initWithFrame:CGRectMake(0, self.X_NavHeight, X_Width, 50)];
    _bgView.backgroundColor = UIColor.whiteColor;
    [self.view addSubview:_bgView];
    
    _titleLb = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 150, 50)];
    _titleLb.font = [UIFont systemFontOfSize:15];
    _titleLb.textColor = UIColor.blackColor;
    _titleLb.text = @"自动关机时间";
    [_bgView addSubview:_titleLb];
    
    _minuteLb = [[UILabel alloc] initWithFrame:CGRectMake(X_Width-15-25, 0, 25, 50)];
    _minuteLb.font = [UIFont systemFontOfSize:12];
    _minuteLb.textColor = UIColor.blackColor;
    _minuteLb.text = @"分钟";
    [_bgView addSubview:_minuteLb];
    
    _tf = [[UITextField alloc] initWithFrame:CGRectMake(X_Width-125, 0, 80, 50)];
    _tf.font = [UIFont systemFontOfSize:12];
    _tf.textAlignment = NSTextAlignmentRight;
    _tf.keyboardType = UIKeyboardTypeNumberPad;
    _tf.textColor = UIColor.blackColor;
    _tf.placeholder = @"请输入分钟";
    _tf.returnKeyType = UIReturnKeyDone;
    [_bgView addSubview:_tf];
    
    _changeButton = [[UIButton alloc] initWithFrame:CGRectMake(15, X_Height-60, X_Width-30, 50)];
    [_changeButton setTitle:@"修改" forState:UIControlStateNormal];
    _changeButton.titleLabel.font = [UIFont systemFontOfSize:17];
    [_changeButton setTintColor:UIColor.whiteColor];
    _changeButton.backgroundColor = UIColor.blackColor;
    _changeButton.layer.cornerRadius = 5;
    [_changeButton addTarget:self action:@selector(changeButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_changeButton];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(endEdit)];
    [self.view addGestureRecognizer:tap];
}


- (void)endEdit {
    [self.view endEditing:true];
}

- (void)changeButtonAction {
    
    int minute = [_tf.text intValue];
    if (minute == 10000) {
        [LMAPI setAutoShutdownTime:0];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else if (minute == 5) {
        [LMAPI setAutoShutdownTime:1];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else if (minute == 15) {
        [LMAPI setAutoShutdownTime:2];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else if (minute == 30) {
        [LMAPI setAutoShutdownTime:3];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else if (minute == 60) {
        [LMAPI setAutoShutdownTime:4];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else if (minute == 120) {
        [LMAPI setAutoShutdownTime:5];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else if (minute == 240) {
        [LMAPI setAutoShutdownTime:6];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else if (minute == 480) {
        [LMAPI setAutoShutdownTime:7];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else if (minute == 1440) {
        [LMAPI setAutoShutdownTime:8];
        [XSingleView.sharedInstance show:@"修改成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }else {
        [XSingleView.sharedInstance show:@"请输入正确的时间"];
    }
    
}


@end
